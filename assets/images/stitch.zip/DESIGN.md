# Design System Strategy: The Intelligent Aura

## 1. Overview & Creative North Star
**Creative North Star: "The Ethereal Mentor"**
This design system moves away from the rigid, "utility-only" look of traditional educational software. Instead, it adopts a high-end editorial feel that combines academic authority with a dreamlike, aspirational quality. By utilizing **The Intelligent Aura**, we create an environment that feels less like a chore and more like a focused, premium sanctuary for learning.

The "Ethereal Mentor" aesthetic is achieved through:
*   **Intentional Asymmetry:** Breaking the grid with overlapping illustrations and off-center background blurs to stimulate creativity.
*   **Atmospheric Depth:** Using layered surfaces and glassmorphism rather than flat lines to create a sense of focus.
*   **High-Contrast Scale:** Pairing massive, expressive `display-lg` typography with generous white space to guide the student’s eye effortlessly through complex information.

---

## 2. Colors & Surface Philosophy
The palette is built on a foundation of sophisticated purples and blues, accented by a "success" green that feels like an organic growth sprout rather than a harsh notification.

### The "No-Line" Rule
**Explicit Instruction:** Traditional 1px borders are prohibited for sectioning. 
Structure must be defined through:
*   **Tonal Transitions:** Use `surface` (background) against `surface_container_low` (section).
*   **Atmospheric Blurs:** Use the signature purple-blue blur shapes behind content cards to provide a "glow" that defines the active area.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of semi-transparent materials:
*   **Base:** `surface` (#fcf8ff) – The expansive, clean canvas.
*   **Containers:** Use `surface_container_low` for large content areas. Nested elements (like a question inside a quiz card) should use `surface_container_lowest` (#ffffff) to "pop" toward the user.
*   **Glassmorphism:** For floating navigation or modal overlays, use `surface_container` with a `backdrop-filter: blur(20px)` and an opacity of 80%.

### Signature Textures
Main CTAs must use a linear gradient from `primary` (#4d41df) to `secondary` (#005bbe) at a 135-degree angle. This provides a "visual soul" that flat buttons lack, suggesting energy and progress.

---

## 3. Typography: The Editorial Voice
We utilize two distinct typefaces to balance personality with readability.

*   **Display & Headlines (Plus Jakarta Sans):** Chosen for its modern, geometric clarity. Use large scales (`display-lg`, `headline-md`) for headers to create an editorial, magazine-like feel.
*   **Body & Labels (Manrope):** A soft, premium sans-serif with excellent legibility for long-form study material. It feels approachable yet scholarly.

**Hierarchy as Identity:** 
Always lead with a bold `headline-lg` in `on_surface`. Follow immediately with `body-md` in `on_surface_variant` to create a clear "Primary-Secondary" relationship that makes the app feel intuitive and "scannable" for busy students.

---

## 4. Elevation & Depth
We eschew the "material" look for a more organic, ambient approach to depth.

*   **The Layering Principle:** Stack `surface_container` tiers. A `surface_container_highest` card sitting on a `surface` background creates a natural elevation without the need for artificial shadows.
*   **Ambient Shadows:** For floating elements, use a shadow with a 40px blur, 10px Y-offset, and 6% opacity using a tinted color (`primary_fixed_dim`). Avoid gray shadows; shadows should feel like the object is blocking a purple/blue light source.
*   **The "Ghost Border" Fallback:** If a boundary is strictly required for accessibility, use the `outline_variant` token at **15% opacity**. It should be a suggestion of a line, not a barrier.

---

## 5. Components

### Large Gradient Buttons
*   **Primary:** `primary` to `secondary` gradient. 24px corner radius (`lg`). Heavy horizontal padding (`spacing-8`).
*   **Secondary:** Ghost style. No background, `outline_variant` (15% opacity) border, text in `primary`.
*   **Animation:** On tap, scale down to 0.96 and increase shadow spread to simulate physical depression.

### Input Fields (The "Soft Entry")
*   **Style:** Large height (minimum 64px), `surface_container_highest` background, 16px radius (`md`). 
*   **Interaction:** On focus, the background shifts to `surface_container_lowest` (pure white) with a 2px `primary` "Ghost Border."

### 24px Rounded Cards
*   **Structure:** No dividers. Use `spacing-6` (2rem) between content blocks inside the card.
*   **Visuals:** Top-align the centered logo (approx 32px height) to anchor the screen hierarchy.

### Education Chips
*   **Selection:** Use `tertiary_container` for "Correct" states and `primary_fixed` for active selection.
*   **Radius:** Always use `full` (9999px) for chips to contrast against the `lg` card corners.

### Lists
*   **Forbid Dividers:** Separate list items using `spacing-3` vertical gaps and a subtle background shift on hover/tap (`surface_variant`).

---

## 6. Do’s and Don'ts

### Do
*   **Do** respect the iPhone 15 Pro safe areas; ensure headers sit comfortably below the Dynamic Island.
*   **Do** center the brand logo at the top of every primary screen to maintain brand authority.
*   **Do** use the Light Green (`tertiary`) accent sparingly—only for "Success," "Correct Answer," or "Progress Completed" states.

### Don't
*   **Don't** use 100% black text. Always use `on_surface` (#1b1b24) to maintain the "premium soft" feel.
*   **Don't** use standard "drop shadows." If it doesn't look like an ambient glow, it's too heavy.
*   **Don't** cram content. If a screen feels full, increase the `spacing` scale and move content to a secondary card or scrollable area. The "Ethereal Mentor" needs room to breathe.